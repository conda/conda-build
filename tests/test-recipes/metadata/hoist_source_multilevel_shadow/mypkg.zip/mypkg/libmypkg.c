#include<mypkg/awesomeheader.h>
int flow() {
    return my_name_is_bob;
}
