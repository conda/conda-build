from setuptools import setup
setup(name="test", version='480')
