

set -ex



echo "A-OK"
exit 0
exit 0
