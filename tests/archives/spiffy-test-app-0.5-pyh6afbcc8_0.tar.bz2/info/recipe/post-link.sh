cat << EOF > "$PREFIX/.messages.txt"
{
    "PREFIX": "$PREFIX",
    "PKG_NAME": "$PKG_NAME",
    "PKG_VERSION": "$PKG_VERSION",
    "PKG_BUILDNUM": "$PKG_BUILDNUM"
}
EOF
