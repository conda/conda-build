import json
import os


def main():
    print(json.dumps(os.environ, indent=2, sort_keys=True,
                     separators=(',', ': ')))


def helper():
    print(json.dumps(os.environ, indent=2, sort_keys=True,
                     separators=(',', ': ')))
